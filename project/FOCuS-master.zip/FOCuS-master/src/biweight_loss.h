//#ifdef ___BIWEIGHT_H___
//#define ___BIWEIGHT_H___

#include "FOCuS.h"

void update_cost_biweight(std::list<Quadratic>&, const double&, const double&, const double&);

//#endif