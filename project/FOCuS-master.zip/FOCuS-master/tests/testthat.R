library(testthat)
library(FOCuS)

test_check("FOCuS")
